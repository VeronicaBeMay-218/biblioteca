from django.contrib import admin
#
from .models import Colors, Product
#

admin.site.register(Colors)
admin.site.register(Product)
