from django.apps import AppConfig


class LectorConfig(AppConfig):
    name = 'lector'
