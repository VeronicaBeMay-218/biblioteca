from django.apps import AppConfig


class AutorConfig(AppConfig):
    name = 'autor'
